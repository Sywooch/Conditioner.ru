#SXD20|20011|50716|50629|2017.06.07 19:47:44|conditioner_yii2|utf8|8|57|
#TA system_about`2`16384|system_comments`0`16384|system_comments_news`0`16384|system_news`0`16384|system_orders`50`16384|system_photo_catalog`0`16384|system_photo_position`3`16384|system_users`2`16384
#EOH

#	TC`system_about`utf8_general_ci	;
CREATE TABLE `system_about` (
  `id_about` int(1) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `info` text NOT NULL,
  `description` text NOT NULL,
  `keywords` text NOT NULL,
  `hide` enum('show','hide') NOT NULL,
  PRIMARY KEY (`id_about`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`system_about`utf8_general_ci	;
INSERT INTO `system_about` VALUES 
(1,'Сколько стоит монтаж кондиционера?','<p style=\"text-align:center\"><strong>Цены на монтаж кондиционера:</strong></p>\r\n\r\n<p style=\"text-align:center\"><strong>Стоимость стандартного монтажа*</strong></p>\r\n\r\n<p><em>*&nbsp;<u>Стандартный монтаж</u></em><br />\r\n<br />\r\n- Длина медной магистрали(фрионовой трассы) не более 5 метров<br />\r\n- Расположение внешнего блока кондиционера под окно или рядом с окном (до 2-го этажа), установка не выше 3-х метров с улицы (для 1-2 этажей)<br />\r\n- Бурение одного сквозного отверстия<br />\r\n- Длина межблочного кабеля не более 2 метров</p>\r\n\r\n<p>В базовый монтаж включена установка внешнего блока, не требующая вызова автовышки или работы альпиниста.<br />\r\n<span style=\"color:#FF0000\">В случае несоответствия</span> установки данным требованиям, <span style=\"color:#FF0000\">стоимость</span> монтажа <span style=\"color:#FF0000\">пересчитывается.</span></p>\r\n\r\n<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<table align=\"left\" border=\"1\" cellpadding=\"1\" cellspacing=\"1\" class=\"table table-bordered table-striped\" style=\"width:100%\">\r\n	<thead>\r\n		<tr>\r\n			<th scope=\"col\">Мощьность кондиционера</th>\r\n			<th scope=\"col\">Стоимость монтажа</th>\r\n			<th scope=\"col\"><strong>Стоимость метра фрионовой трассы</strong></th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>7&nbsp;- 2 000 Вт</td>\r\n			<td>2500</td>\r\n			<td>500 руб за 1 метр</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;9 - 2650 Вт</td>\r\n			<td>2500</td>\r\n			<td>500 (600 если 1/2 труба)&nbsp;руб за 1 метр</td>\r\n		</tr>\r\n		<tr>\r\n			<td>12 - 3500 Вт</td>\r\n			<td>2700</td>\r\n			<td>700&nbsp;руб за 1 метр</td>\r\n		</tr>\r\n		<tr>\r\n			<td>18 -&nbsp;5300 Вт</td>\r\n			<td>4000</td>\r\n			<td>800 руб за 1 метр</td>\r\n		</tr>\r\n		<tr>\r\n			<td>24 - 7000 Вт</td>\r\n			<td>4500</td>\r\n			<td>800 руб за 1 метр</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p style=\"text-align:center\"><strong><em>Стоимость отдельных работ</em></strong>&nbsp;<em>(не входящих в стандартный монтаж)</em></p>\r\n\r\n<p><br />\r\n- Штроба по монолиту: 2000 руб. погонный метр.</p>\r\n\r\n<p>- Штроба по кирпичу: 800 руб. погонный метр.</p>\r\n\r\n<p>- Удлинение медной трассы:&nbsp; от 700 руб. за погонный метр.</p>\r\n\r\n<p>- Пайка медной трассы: 1000 руб.</p>\r\n\r\n<p>- Заказ автовышки : от 1500 руб за час</p>\r\n\r\n<p>- Короб для медной магистрали (60x60 мм): 400 руб. погонный метр.</p>\r\n\r\n<p>- Короб для кабеля питания: 150 руб. погонный метр.</p>\r\n\r\n<p>- Бурение дополнительного отверстия: 400 руб.</p>\r\n','Сколько стоит монтаж кондиционера? Цены на услуги по монтажу кондиционера в городе Керчь и области.','Кондиционеры, установка в Керчи, заправка кондиционеров, чистка кондиционера','show'),
(2,'Гарантия на нашу работу','<p>Гарантия на установку - год! Гарантия не распостраняеться на б/у кондиционер!</p>\r\n\r\n<p>Какие проблемы могут быть?:</p>\r\n\r\n<p>- Утечка фриона, последствия:</p>\r\n\r\n<p>Сплит система работает как вентилятор! Не охлаждая/обогревая воздух.</p>\r\n\r\n<p>- Скапливание конденсата во внутренем блоке, последствия:</p>\r\n\r\n<p>Конденсат капает на обои, паркет, мебель...</p>\r\n\r\n<p>Многие фирмы, производят некачественные монтажи и не дают&nbsp;гарантии!</p>\r\n\r\n<p>Гарантию на срок службы сплит системы дает производитель и на каждую систему свой срок! Замена или ремонт по гарантии производиться магазином в котором была куплена сплит система.</p>\r\n\r\n<p><strong>Советы от профессионалов:</strong></p>\r\n\r\n<p>Для сохранения ресурса сплит системы, необходимо её обслуживать каждый год в осене-весений период, а иммено:</p>\r\n\r\n<p>Производить обязательную чистку внутреннего блока и при необходимости наружнего. Это нужно не только, чтоб сохранить ресурс сплит системы но и для того, чтобы обеспечить безопасность своему здоровью!</p>\r\n','Наши гарантии и советы по использованию сплит систем.','Наши гарантии, гарантия на монтаж, гарантия на услуги, каковы гарантии, обслуживание сплит систем','show')	;
#	TC`system_comments`utf8_general_ci	;
CREATE TABLE `system_comments` (
  `id_position` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `phone` tinytext NOT NULL,
  `city` tinytext,
  `comment` text NOT NULL,
  `answer` text NOT NULL,
  `put_date` datetime NOT NULL,
  `hide` enum('show','hide') NOT NULL,
  PRIMARY KEY (`id_position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`system_comments_news`utf8_general_ci	;
CREATE TABLE `system_comments_news` (
  `id_position` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `comment` text NOT NULL,
  `answer` text NOT NULL,
  `put_date` datetime NOT NULL,
  `hide` enum('show','hide') NOT NULL,
  `id_news` int(11) NOT NULL,
  PRIMARY KEY (`id_position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`system_news`utf8_general_ci	;
CREATE TABLE `system_news` (
  `id_news` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `put_date` date NOT NULL,
  `hide` enum('show','hide') NOT NULL,
  PRIMARY KEY (`id_news`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TC`system_orders`utf8_general_ci	;
CREATE TABLE `system_orders` (
  `id_contact` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `phone` tinytext NOT NULL,
  `subject` enum('installation','cleaning','refuel','repair') NOT NULL,
  `message` text NOT NULL,
  `comment` text,
  `put_date` datetime NOT NULL,
  `hide` enum('show','hide','canceled') NOT NULL,
  PRIMARY KEY (`id_contact`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT	;
#	TD`system_orders`utf8_general_ci	;
INSERT INTO `system_orders` VALUES 
(1,'Буденного 9','+79788619245','cleaning','Буденного 9 кв 227','','2017-04-17 13:51:20','hide'),
(2,'Елена','+79788360179','cleaning','Блюхера 25 кв 111','Кондиционер Мидеа,\r\n\"Мидеа вам о чем нибудь говорит?\"','2017-04-17 16:55:59','hide'),
(3,'Белла','+79788619019','cleaning','Айвазовского 18 кв 4\r\n2 мая на 15 часов','','2017-05-01 16:01:24','hide'),
(4,'Марат 2','+79789187998','cleaning','Марат 2 кв 49 код 358\r\n10 мая на 15 часов, еще надо соседке почистить!','','2017-05-01 16:05:24','hide'),
(5,'Валентина Федоровна','+79788136393','cleaning','Буденного 11 кв 56\r\nВ субботу на 9 утра','','2017-04-18 09:13:16','hide'),
(6,'Орджоникидзе 124','+79788260245','cleaning','Орджоникидзе 124 кв 11 на 15 часов','','2017-04-20 12:10:33','hide'),
(7,'Ворошилова 15','+79787177841','cleaning','Ворошилова 15 кв 10 на 16 часов','Сломан золотник на LG хотел заправку, потом отказался, я говорил 2000 рублей ему.','2017-04-20 13:14:18','hide'),
(8,'Анна Генадиевна','+79787021407','cleaning','','','2017-04-20 17:49:02','hide'),
(9,'Галина Григорьевна','+79787968440','cleaning','На 7-е мая\r\nОрджоникидзе 110 кв 29','Также надо лентой обмотать, предворительно посчитал на 1300 рублей + скидка 10%(Учтена!)','2017-04-22 14:16:15','hide'),
(10,'Кирова 79','+79780809638','cleaning','Кирова 79 кв 16\r\nНа 12 часов для','','2017-04-24 14:23:46','hide'),
(11,'Марат 19','+79780093535','cleaning','Марат 19 кв 28\r\nНа 14 часов','','2017-04-26 17:56:59','hide'),
(12,'Орджоникидзе 17','+79883248851','cleaning','Орджоникидзе 17 кв 18 1-й этаж 3 кондиционера и заправить','','2017-04-28 18:23:02','hide'),
(13,'Генерала Петрова 66','+79183575837','cleaning','Генерала Петрова 66 кв 48\r\nНа 15 часов в субботу','','2017-05-29 12:36:00','hide'),
(14,'Нелля','+79787864923','cleaning','Буденного 32 кв 1 на 17-18 часов','','2017-05-02 00:26:54','hide'),
(15,'Георгий','+79788579730','installation','Пролетарская 6 магазин индюшонок','','2017-05-02 11:33:06','hide'),
(16,'Буденного 9 кв 78','+79788206754','cleaning','Буденного 9 кв 78 на 9 утра','','2017-05-02 11:53:10','hide'),
(17,'Георгий','+79788579730','refuel','Рынок центральный, ул. пролетарская, магазин Наша Ряба','','2017-05-03 18:15:17','hide'),
(18,'Буденного 9 кв 244','+79787750073','cleaning','Буденного 9 кв 244 на 10 утра','','2017-05-04 09:12:22','hide'),
(19,'Дмитрий','+79780585873','installation','Блюхера 6 кв 26 завтра на 9 утра','','2017-05-04 13:20:30','hide'),
(20,'Бодни 43','Не указан','cleaning','Бодни 43 на 10 утра','','2017-05-05 23:20:41','hide'),
(21,'1-й пятилетки 33','+79787178999','cleaning','1-й пятилетки 33 кв 25\r\nЧистка, мелкий ремонт на понедельник','','2017-05-08 08:24:56','hide'),
(22,'Ворошилова 15','+79780016385','cleaning','Ворошилова 15 кв 38','','2017-05-11 17:33:01','hide'),
(23,'Вокзальное шоссе 35','+79892946965','installation','Вокзальное шоссе 35 кв 10','Также установили ей козырек.','2017-05-06 15:23:59','hide'),
(24,'Свердлова 84','+79788773890','cleaning','Свердлова 84, первый этаж','','2017-05-12 10:25:57','hide'),
(25,'Салон красоты','+79787089137','refuel','Салон красоты, 2-й этаж, милицейский переулок','','2017-05-12 14:27:49','hide'),
(26,'Петрович','+79789189583','cleaning','Генерала петрова 20 кв 11\r\nТакже надо прочистить дренаж.','','2017-05-12 15:31:34','hide'),
(27,'+79787796296','+79787796296','installation','','На понедельник, вторник! Либо он позвонит либо ему набрать. + у него чистка, и монтаж 7 - ки.','2017-05-16 10:57:04','canceled'),
(28,'Тамара Ивановна','+79787021035','installation','На маме, в субботу','2 кондиционера в пансионате, ставили. ','2017-05-16 10:59:59','hide'),
(29,'Миндальный дом 7','+79788595631','cleaning','Миндальный дом 7, возле гаи','','2017-05-18 23:17:37','hide'),
(30,'+79788568833','+79788568833','cleaning','На субботу, Столичное шоссе','','2017-05-18 23:22:10','canceled'),
(31,'Фурманова 17/27','+79788612063','cleaning','Фурманова 17/27','','2017-05-20 19:27:07','hide'),
(32,'Ворошилова 3','+79787442130','cleaning','Ворошилова 3 кв 59 код 256','','2017-05-22 09:48:24','hide'),
(33,'+79788010193','+79788010193','cleaning','Ульяновых на четверг 1,06,2017 на 8,30 утра','','2017-05-25 15:49:45','hide'),
(34,'Блюхера 17 кв 51','+79787533568','repair','Блюхера 17 кв 51\r\nДемонтаж на 17 часов','','2017-05-24 08:43:43','hide'),
(35,'Белла','+79788619019','cleaning','Горького 13 кв 16','','2017-05-26 08:45:35','hide'),
(36,'Мирошника 28/30','+79787164966','refuel','Мирошника 28/30\r\nСклады','','2017-05-28 11:48:41','hide'),
(37,'Орджоникидзе 90 кв 40','+79787327518','cleaning','Орджоникидзе 90 кв 40','','2017-05-31 08:49:50','hide'),
(38,'Героев сталинграда 10 кв 55','+79781101968','refuel','Героев сталинграда 10 кв 55','','2017-05-31 08:50:38','hide'),
(39,'Мичурино','+79780190862','installation','Мичурино садовый переулок 18','','2017-05-31 12:34:59','hide'),
(40,'Орджоникидзе 92 кв 78','+79788898852','cleaning','Орджоникидзе 92 кв 78','','2017-05-31 15:01:05','hide'),
(41,'улица 12 Апреля кв 18','+79782190217','installation','улица 12 Апреля 1961 года, 18','','2017-05-31 16:03:40','hide'),
(42,'улица Ворошилова, 1/1','+79788257923','cleaning','улица Ворошилова, 1/1 кв 7','','2017-06-02 15:05:32','hide'),
(43,'Переулок линейный 18','+79892393151','cleaning','Переулок линейный 18','Опасная тетя, разобрала кондиционер и боится пыли.','2017-06-02 15:06:33','hide'),
(44,'Курсантов 20','+79787217948','cleaning','Курсантов 20','Позвонить во вторник, предварительно на среду. 4 кондиционера по 90 рублей каждый и нужна лестница.','2017-06-02 19:55:07','show'),
(45,'Еременко 41','+79788600977','cleaning','Еременко 41 кв 3 код 38\r\n','Первый этаж, на 17 число около 16 часов вечера!','2017-06-07 19:33:51','show'),
(46,'Славы 6 кв 18','+79788339654','installation','Славы 6 кв 18','','2017-06-03 09:38:21','hide'),
(47,'Алексей','+79788301325','cleaning','2-я Митридатская дом 82','','2017-06-06 12:41:35','hide'),
(48,'Заречная 8 кв 15','+79780031338','refuel','Заречная 8 кв 15 код 39','','2017-06-07 08:43:08','hide'),
(49,'Орджоникидзе 110 кв 38','+79788638210','installation','Орджоникидзе 110 кв 38',\N,'2017-06-07 13:44:42','show'),
(50,'Генерала Петрова 16 кв 198','+79785597804','installation','',\N,'2017-06-07 09:13:55','show')	;
#	TC`system_photo_catalog`utf8_general_ci	;
CREATE TABLE `system_photo_catalog` (
  `id_catalog` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `description` text NOT NULL,
  `hide` enum('show','hide') NOT NULL,
  PRIMARY KEY (`id_catalog`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TC`system_photo_position`utf8_general_ci	;
CREATE TABLE `system_photo_position` (
  `id_position` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `alt` tinytext NOT NULL,
  `img_small` tinytext NOT NULL,
  `img_big` tinytext NOT NULL,
  `hide` enum('show','hide') NOT NULL,
  `id_catalog` int(11) NOT NULL,
  PRIMARY KEY (`id_position`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`system_photo_position`utf8_general_ci	;
INSERT INTO `system_photo_position` VALUES 
(1,'Air Green','Внутренний блок Air Green 12 ','s_photo-528244.jpeg','photo-528244.jpeg','show',1),
(2,'Air Green','Air Green 12 out','s_photo-1918221725.jpeg','photo-1918221725.jpeg','show',1),
(3,'Air Green','Air Green 12 out','s_photo-1926277.jpeg','photo-1926277.jpeg','show',1),
(4,'Besshof','Besshof 09','s_photo-1171618.jpeg','photo-1171618.jpeg','show',1)	;
#	TC`system_users`utf8_general_ci	;
CREATE TABLE `system_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(254) NOT NULL,
  `username` varchar(32) NOT NULL DEFAULT '',
  `password` varchar(254) NOT NULL,
  `status` smallint(6) NOT NULL,
  `auth_key` varchar(32) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `role` enum('admin','user') NOT NULL,
  `secret_key` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_username` (`username`),
  UNIQUE KEY `uniq_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`system_users`utf8_general_ci	;
INSERT INTO `system_users` VALUES 
(1,'maxkyivua@gmail.com','pimpys','$2y$13$FmpzAZZqKUVB2vsh0qWFpOc17uwjQQb3iAppHFifdvPkLIwyCX0m6',10,'mrPE9wTTZD04Hszb5QkHsmURej7f-Awx',1492287365,1492287365,'admin',\N),
(2,'maxkyivua@gmail.ua','Max','$2y$13$vxUb/3rbGOxA1QXEJGRNR.OeKwmVd1ioMgzZo1D8OHm4LFngLEh1u',10,'hOd-aeSwK31ZzYueubHcDF6toHy1FfLq',1492288339,1495140298,'admin','k9FIj-N3zw0RW7Si0bQHNGD6be1w290r_1494367323')	;
